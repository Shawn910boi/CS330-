﻿///////////////////////////////////////////////////////////////////////////////
// 2D Game Program
// ===============
// This program implements a simple 2D game using OpenGL and GLFW. The game
// involves circular objects (referred to as "balls") that move within a window 
// and interact with static rectangular bricks. The primary features of the game
// include:
// 
// - **Bricks**: Represented as either reflective or destructible. Reflective 
//   bricks change the direction of the balls upon collision, while destructible
//   bricks disappear when hit.
// - **Balls**: Circular objects that move randomly within the window. Their 
//   motion is influenced by collisions with bricks and window boundaries.
// - **Input Handling**: Players can spawn new balls by pressing the spacebar or 
//   close the game window by pressing the ESC key.
//
// Key Features:
// -------------
// - **Brick Types**:
//   - Reflective bricks alter the direction of the balls.
//   - Destructible bricks disappear upon collision.
// - **Ball Motion**:
//   - Balls move in random directions and bounce upon hitting boundaries.
//   - Collisions with bricks are handled dynamically.
// - **User Input**:
//   - Spacebar spawns a new ball at the center with random colors.
//   - ESC closes the application.
// 
// Dependencies:
// -------------
// - GLFW for window creation and input handling.
// - OpenGL for rendering graphics.
// 
// Author: [Deshon Bethea]
// Date: [06/29/2025]
// Assignment: 8-2 Assignment - CS-330 Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////

#include <GLFW/glfw3.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <ctime>

using namespace std;

const float DEG2RAD = 3.14159f / 180;
const int MAX_HITS = 3;

// Brick structure with position, color, size, and durability
struct Brick {
    float x, y, width, height;
    float red, green, blue;
    int hitsLeft;

    Brick(float xx, float yy, float w, float h, int hits) {
        x = xx; y = yy; width = w; height = h; hitsLeft = hits;
        updateColor();
    }

    // Update color based on durability
    void updateColor() {
        red = 1.0f - 0.3f * (MAX_HITS - hitsLeft);
        green = 0.3f * hitsLeft;
        blue = 0.2f * hitsLeft;
    }

    // Draw the brick if it's still active
    void draw() {
        if (hitsLeft <= 0) return;
        glColor3f(red, green, blue);
        glBegin(GL_QUADS);
        glVertex2f(x - width / 2, y - height / 2);
        glVertex2f(x + width / 2, y - height / 2);
        glVertex2f(x + width / 2, y + height / 2);
        glVertex2f(x - width / 2, y + height / 2);
        glEnd();
    }

    // Collision detection with a ball
    bool checkCollision(float cx, float cy, float radius) {
        if (hitsLeft <= 0) return false;
        if (cx + radius > x - width / 2 && cx - radius < x + width / 2 &&
            cy + radius > y - height / 2 && cy - radius < y + height / 2) {
            hitsLeft--;
            updateColor();
            return true;
        }
        return false;
    }
};

// Paddle structure with movement and drawing logic
struct Paddle {
    float x = 0.0f;
    float y = -0.9f;
    float width = 0.3f;
    float height = 0.05f;

    void move(float dx) {
        x += dx;
        if (x < -1 + width / 2) x = -1 + width / 2;
        if (x > 1 - width / 2) x = 1 - width / 2;
    }

    void draw() {
        glColor3f(1.0f, 1.0f, 1.0f);
        glBegin(GL_QUADS);
        glVertex2f(x - width / 2, y - height / 2);
        glVertex2f(x + width / 2, y - height / 2);
        glVertex2f(x + width / 2, y + height / 2);
        glVertex2f(x - width / 2, y + height / 2);
        glEnd();
    }

    // Collision detection with a ball
    bool checkCollision(float cx, float cy, float radius) {
        return cx + radius > x - width / 2 && cx - radius < x + width / 2 &&
            cy + radius > y - height / 2 && cy - radius < y + height / 2;
    }
};

// Ball structure with movement and drawing logic
struct Ball {
    float x, y;
    float vx, vy;
    float radius;

    Ball() {
        reset();
    }

    // Initialize ball to starting position and velocity
    void reset() {
        x = 0.0f;
        y = -0.5f;
        vx = 0.01f;
        vy = 0.015f;
        radius = 0.03f;
    }

    // Update ball position and handle wall collisions
    void move() {
        x += vx;
        y += vy;

        if (x > 1 - radius) {
            x = 1 - radius;
            vx = -fabs(vx) * 0.95f;
        }
        else if (x < -1 + radius) {
            x = -1 + radius;
            vx = fabs(vx) * 0.95f;
        }

        if (y > 1 - radius) {
            y = 1 - radius;
            vy = -fabs(vy) * 0.95f;
        }
    }

    // Draw the ball as a circle
    void draw() {
        glColor3f(1, 1, 1);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i++) {
            float deg = i * DEG2RAD;
            glVertex2f(x + cos(deg) * radius, y + sin(deg) * radius);
        }
        glEnd();
    }
};

vector<Brick> bricks;
Paddle paddle;
vector<Ball> balls;

// Initialize brick layout
void createBricks() {
    bricks.clear();
    int rows = 4;
    int cols = 7;
    float spacingX = 0.3f;
    float spacingY = 0.2f;
    float brickWidth = 0.25f;
    float brickHeight = 0.1f;

    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols - r; c++) {
            float x = (c - (cols - r - 1) / 2.0f) * spacingX;
            float y = 1 - r * spacingY;
            bricks.emplace_back(x, y, brickWidth, brickHeight, MAX_HITS - r % 2);
        }
    }
}

// Handle user input for paddle and spawning balls
void processInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
        paddle.move(-0.02f);
    }
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
        paddle.move(0.02f);
    }
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) {
        Ball b1, b2;
        b1.vx = 0.01f;
        b2.vx = -0.01f;
        balls.push_back(b1);
        balls.push_back(b2);
    }
}

int main() {
    srand(time(NULL));
    if (!glfwInit()) return -1;

    // Create window and OpenGL context
    GLFWwindow* window = glfwCreateWindow(800, 600, "Brick Bounce Game", NULL, NULL);
    if (!window) { glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    createBricks();

    // Main game loop
    while (!glfwWindowShouldClose(window)) {
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-1, 1, -1, 1, 1, -1);

        processInput(window);

        for (int i = 0; i < balls.size(); ++i) {
            balls[i].move();

            // Check paddle collision
            if (paddle.checkCollision(balls[i].x, balls[i].y, balls[i].radius)) {
                balls[i].vy = fabs(balls[i].vy);
            }

            // Check brick collisions
            for (auto& brick : bricks) {
                if (brick.checkCollision(balls[i].x, balls[i].y, balls[i].radius)) {
                    balls[i].vy = -balls[i].vy;

                    // 🎯 Alter ball state on collision
                    balls[i].radius *= 1.1f; // grow ball
                    if (balls[i].radius > 0.08f) balls[i].radius = 0.03f; // reset if too large

                    break;
                }
            }

            // Remove ball if it falls off screen
            if (balls[i].y < -1.1f) {
                balls.erase(balls.begin() + i);
                --i;
                continue;
            }

            balls[i].draw();
        }

        // Draw all bricks and paddle
        for (auto& brick : bricks) brick.draw();
        paddle.draw();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}









